<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b0a2ffc181a58446084261a3ba0a05d9',
      'native_key' => 'indexbot',
      'filename' => 'modNamespace/0215621583a50f38945c38367615f427.vehicle',
      'namespace' => 'indexbot',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4818627666c4accc778b932889d32eec',
      'native_key' => 1,
      'filename' => 'modCategory/26a1ca105f38d7b6dc810b498b1b34ca.vehicle',
      'namespace' => 'indexbot',
    ),
  ),
);